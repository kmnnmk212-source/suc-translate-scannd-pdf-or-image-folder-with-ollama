import sys
import os
from PIL import Image, ImageDraw, ImageFont
import pytesseract
from pdf2image import convert_from_path
import fitz  # PyMuPDF
from utils import translate_text

# الامتدادات المدعومة
IMAGE_EXTENSIONS = {'.jpg', '.jpeg', '.png', '.bmp', '.tiff', '.webp'}
PDF_EXTENSIONS = {'.pdf'}

def get_smart_text(pil_image, pdf_page_object=None):
    """
    تحاول هذه الدالة استخراج النص بأذكى طريقة ممكنة.
    1. تحاول استخراجه كنص رقمي من الـ PDF (أسرع وأدق).
    2. إذا لم تجد نصاً (أو لم يكن ملف PDF)، تستخدم OCR على الصورة.
    """
    text = ""
    
    # محاولة 1: استخراج النص الرقمي إذا توفر كائن الصفحة
    if pdf_page_object:
        try:
            text = pdf_page_object.get_text().strip()
        except Exception:
            pass

    # محاولة 2: إذا كان النص فارغاً أو قصيراً جداً، نلجأ للـ OCR
    if len(text) < 5:
        # print("    ℹ️  Using OCR (Tesseract)...")
        text = pytesseract.image_to_string(pil_image, lang="eng").strip()
    # else:
        # print("    ℹ️  Using Digital Text Extraction (PyMuPDF)...")
        
    return text

def wrap_text(text, font, max_width):
    lines = []
    paragraphs = text.split('\n')
    for paragraph in paragraphs:
        words = paragraph.split()
        if not words:
            continue
        current_line = words[0]
        for word in words[1:]:
            test_line = current_line + " " + word
            line_width = font.getlength(test_line)
            if line_width <= max_width:
                current_line = test_line
            else:
                lines.append(current_line)
                current_line = word
        lines.append(current_line)
    return lines

def create_translated_page_image(original_img, text, font):
    """
    تأخذ صورة وتأخذ النص المستخرج، تترجمه، وترسمه في صورة جديدة
    تعيد كائن صورة Pillow
    """
    if not text:
        return original_img

    # 1. الترجمة
    try:
        translation = translate_text(text)
    except Exception as e:
        print(f"    ❌ Error translating: {e}")
        return original_img

    # 2. إعداد الرسم
    margin = 40
    max_text_width = original_img.width - margin
    arabic_lines = wrap_text(translation, font, max_text_width)

    draw_base = ImageDraw.Draw(original_img)
    extra_height = 40
    line_heights = []

    # حساب الارتفاع
    for ln in arabic_lines:
        bbox = draw_base.textbbox((0,0), ln, font=font, direction="rtl", language="ar")
        h = (bbox[3] - bbox[1]) + 15
        line_heights.append(h)
        extra_height += h

    # إنشاء صورة جديدة بيضاء بالطول الجديد
    new_img = Image.new("RGB", (original_img.width, original_img.height + extra_height), "white")
    new_img.paste(original_img, (0,0))

    draw_new = ImageDraw.Draw(new_img)
    y_offset = original_img.height + 20
    x_position = new_img.width - (margin // 2)

    # الرسم
    for i, ln in enumerate(arabic_lines):
        draw_new.text(
            (x_position, y_offset), 
            ln, 
            fill="black", 
            font=font, 
            direction="rtl", 
            language="ar", 
            anchor="ra"
        )
        y_offset += line_heights[i]
    
    return new_img

def process_file(input_path, output_path, font):
    file_ext = os.path.splitext(input_path)[1].lower()

    # ==========================
    # معالجة الصور العادية
    # ==========================
    if file_ext in IMAGE_EXTENSIONS:
        print(f" -> Processing Image: {os.path.basename(input_path)}")
        img = Image.open(input_path)
        text = get_smart_text(img, pdf_page_object=None)
        
        if not text:
            print("    ⚠️ No text found.")
            img.save(output_path)
            return

        print("    Original text extracted.")
        final_img = create_translated_page_image(img, text, font)
        final_img.save(output_path)
        print(f"    ✅ Saved to: {os.path.basename(output_path)}")

    # ==========================
    # معالجة ملفات PDF
    # ==========================
    elif file_ext in PDF_EXTENSIONS:
        print(f" -> Processing PDF: {os.path.basename(input_path)}")
        
        # 1. فتح ملف PDF كنص (للاستخراج الرقمي)
        try:
            pdf_document = fitz.open(input_path)
        except Exception as e:
            print(f"    ❌ Error opening PDF with PyMuPDF: {e}")
            return

        # 2. تحويل صفحات PDF إلى صور (للرسم عليها)
        # dpi=300 لضمان دقة عالية عند قراءة النصوص بالـ OCR إذا لزم الأمر
        try:
            pdf_images = convert_from_path(input_path, dpi=200)
        except Exception as e:
             print(f"    ❌ Error converting PDF to images: {e}")
             return

        translated_pages = []

        # تكرار لكل صفحة
        total_pages = len(pdf_images)
        for i, page_img in enumerate(pdf_images):
            print(f"    Page {i+1}/{total_pages}...", end="\r")
            
            # جلب كائن الصفحة المقابل من PyMuPDF
            pdf_page_obj = None
            if i < len(pdf_document):
                pdf_page_obj = pdf_document[i]
            
            # استخراج النص (ذكي: دجيتال أولاً، ثم OCR)
            text = get_smart_text(page_img, pdf_page_object=pdf_page_obj)
            
            # الترجمة والرسم
            new_page = create_translated_page_image(page_img, text, font)
            translated_pages.append(new_page)

        print(f"\n    Saving PDF...")
        if translated_pages:
            # حفظ الصفحة الأولى وإرفاق الباقي
            translated_pages[0].save(
                output_path, 
                "PDF", 
                resolution=100.0, 
                save_all=True, 
                append_images=translated_pages[1:]
            )
            print(f"    ✅ PDF Saved to: {os.path.basename(output_path)}")
        
        pdf_document.close()

def process_directory(input_dir, output_dir):
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    # تحميل الخط
    try:
        font = ImageFont.truetype(
            "/usr/share/fonts/opentype/fonts-hosny-amiri/Amiri-Regular.ttf", 26
        )
    except:
        font = ImageFont.load_default()

    files = os.listdir(input_dir)
    # تصفية الملفات (صور أو PDF)
    valid_files = [
        f for f in files 
        if os.path.splitext(f)[1].lower() in IMAGE_EXTENSIONS.union(PDF_EXTENSIONS)
    ]
    
    total = len(valid_files)
    print(f"\n🚀 Found {total} files in '{input_dir}'\n")

    for i, filename in enumerate(valid_files, 1):
        input_path = os.path.join(input_dir, filename)
        output_path = os.path.join(output_dir, filename)
        
        process_file(input_path, output_path, font)

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python main.py <input_folder> <output_folder>")
        sys.exit(1)
    
    process_directory(sys.argv[1], sys.argv[2])
