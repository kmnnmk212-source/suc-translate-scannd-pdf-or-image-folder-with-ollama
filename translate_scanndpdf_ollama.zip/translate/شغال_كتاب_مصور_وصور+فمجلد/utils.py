import requests

OLLAMA_URL = "http://localhost:11434/api/chat"

def translate_text(text: str) -> str:
    payload = {
        "model": "gpt-oss:20b",
        "stream": False,
        "messages": [
            {
                "role": "system",
                "content": "You are a professional translator; translate the following English text into clear Arabic."
            },
            {
                "role": "user",
                "content": text
            }
        ]
    }
    response = requests.post(OLLAMA_URL, json=payload, timeout=60)
    response.raise_for_status()
    data = response.json()
    return data["message"]["content"].strip()

