import sys
import os
from PIL import Image, ImageDraw, ImageFont
import pytesseract
from utils import translate_text

# الامتدادات المدعومة للصور
VALID_EXTENSIONS = {'.jpg', '.jpeg', '.png', '.bmp', '.tiff', '.webp'}

def extract_text(img):
    txt = pytesseract.image_to_string(img, lang="eng")
    return txt.strip()

def wrap_text(text, font, max_width):
    lines = []
    paragraphs = text.split('\n')
    for paragraph in paragraphs:
        words = paragraph.split()
        if not words:
            continue
        current_line = words[0]
        for word in words[1:]:
            test_line = current_line + " " + word
            line_width = font.getlength(test_line)
            if line_width <= max_width:
                current_line = test_line
            else:
                lines.append(current_line)
                current_line = word
        lines.append(current_line)
    return lines

def process_single_image(input_path, output_path, font):
    """
    تقوم هذه الدالة بمعالجة صورة واحدة وحفظها
    """
    try:
        print(f" -> Processing: {os.path.basename(input_path)}")
        img = Image.open(input_path)

        text = extract_text(img)
        
        if not text:
            print("    ⚠️ No text found (Skipping translation).")
            # حفظ الصورة كما هي إذا لم يوجد نص (أو يمكنك تجاوزها بـ return)
            img.save(output_path)
            return

        print("    Original text extracted.")
        
        # الترجمة
        try:
            translation = translate_text(text)
            print("    Translation received.")
        except Exception as e:
            print(f"    ❌ Error during translation: {e}")
            return

        # إعداد الأبعاد والالتفاف
        margin = 40
        max_text_width = img.width - margin
        arabic_lines = wrap_text(translation, font, max_text_width)

        draw_base = ImageDraw.Draw(img)
        extra_height = 20
        line_heights = []
        
        for ln in arabic_lines:
            bbox = draw_base.textbbox((0,0), ln, font=font, direction="rtl", language="ar")
            h = (bbox[3] - bbox[1]) + 10
            line_heights.append(h)
            extra_height += h

        # إنشاء الصورة الجديدة
        new_img = Image.new("RGB", (img.width, img.height + extra_height), "white")
        new_img.paste(img, (0,0))

        draw_new = ImageDraw.Draw(new_img)
        y_offset = img.height + 10
        x_position = new_img.width - (margin // 2)

        for i, ln in enumerate(arabic_lines):
            draw_new.text(
                (x_position, y_offset), 
                ln, 
                fill="black", 
                font=font, 
                direction="rtl", 
                language="ar", 
                anchor="ra"
            )
            y_offset += line_heights[i]

        new_img.save(output_path)
        print(f"    ✅ Saved to: {os.path.basename(output_path)}")

    except Exception as e:
        print(f"    ❌ Error processing image: {e}")

def process_directory(input_dir, output_dir):
    # إنشاء مجلد المخرجات إذا لم يكن موجوداً
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
        print(f"Created output directory: {output_dir}")

    # تحميل الخط مرة واحدة لتوفير الأداء
    try:
        font = ImageFont.truetype(
            "/usr/share/fonts/opentype/fonts-hosny-amiri/Amiri-Regular.ttf", 26
        )
    except:
        print("Warning: Arabic font not found, falling back to default.")
        font = ImageFont.load_default()

    # جلب قائمة الملفات
    files = os.listdir(input_dir)
    images = [f for f in files if os.path.splitext(f)[1].lower() in VALID_EXTENSIONS]
    
    total = len(images)
    print(f"\n🚀 Found {total} images in '{input_dir}'\n")

    for i, filename in enumerate(images, 1):
        input_path = os.path.join(input_dir, filename)
        output_path = os.path.join(output_dir, filename)
        
        print(f"[{i}/{total}] Starting...")
        process_single_image(input_path, output_path, font)

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python main.py <input_folder> <output_folder>")
        sys.exit(1)
    
    input_folder = sys.argv[1]
    output_folder = sys.argv[2]

    if not os.path.isdir(input_folder):
        print(f"Error: '{input_folder}' is not a valid directory.")
        sys.exit(1)

    process_directory(input_folder, output_folder)
